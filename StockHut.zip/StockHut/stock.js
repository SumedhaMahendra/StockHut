//Import
const express = require("express");
var bodyParser = require("body-parser");
var mysql = require('mysql');
const app = express();
var path = require('path');
const { IEXCloudClient } = require("node-iex-cloud");
const fetch = require("node-fetch");
var cons = require('consolidate');
const session = require('express-session');

//For rendering html pages
app.engine('html', cons.swig)
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');

//For creating session
app.use(session({ secret: 'stock', saveUninitialized: true, resave: true }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var sess;

var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.use(express.static(path.join(__dirname, 'public')));

//App.gets

app.get("/", (req, res) => { res.render("index"); });
app.get("/index", (req, res) => { res.render("index"); });
app.get("/register", (req, res) => { res.render("register"); });

app.get("/buy", (req, res) => {
    sess = req.session;
    if (sess.username) {
        res.render("buy", { message2: sess.username });
    }
    else {
        res.render("index");
    }

});

app.get("/history", (req, res) => {
    sess = req.session;
    if (sess.username) {
        var mysql = require('mysql');
        var con = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "",
            database: "stock"
        });

        con.connect(function (err) {
            if (err) throw err;
            else {
                console.log("Connected to database for history");
                var sql = "SELECT * FROM stocks where username = '" + sess.username + "'";
                con.query(sql, function (err, result, fields) {
                    if (err) throw err;

                    console.log(sql);
                    console.log(result);

                    temp = JSON.parse(JSON.stringify(result));
                    var check = temp[0];

                    if (check) {
                        console.log(result);

                        Object.keys(result).forEach(function (key) {
                            row = result[key];
                            console.log(row.symbol);
                            console.log(key);
                        });

                        for (var i = 0; i < result.length; i++) {
                            result[i].transacted = JSON.stringify(result[i].transacted);
                            result[i].transacted = result[i].transacted.replace('T', ' ');
                            result[i].transacted = result[i].transacted.replace('Z', '');
                            result[i].transacted = result[i].transacted.replace('\"', '');
                            result[i].transacted = result[i].transacted.replace('\"', '');
                        }

                        console.log("Record Retrieved Successfully");

                        res.render("history", { message: result, message2: sess.username });
                    }

                    else {
                        res.render("history", { error: "No transactions to show!", message2: sess.username });

                    }

                });
            }
        });
    }

    else {
        res.render("index");
    }
});

app.get("/home", (req, res) => {

    sess = req.session;
    if (sess.username) {
        console.log("ghar pe");

        var mysql = require('mysql');
        var con = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "",
            database: "stock"
        });

        con.connect(function (err) {
            if (err) throw err;
            else {
                console.log("Connected to database for home");
                var sql = "SELECT *, sum(shares) as shares FROM stocks where username = '" + sess.username + "' GROUP BY symbol HAVING (SUM(shares)) > 0";
                con.query(sql, function (err, result) {
                    if (err) throw err;

                    console.log(result);
                    console.log(result[0]);

                    temp = JSON.parse(JSON.stringify(result));
                    var check = temp[0];

                    console.log(check);
                    console.log(temp);

                    if (check) {

                        const stock_price = async function (symbol) {

                            try {
                                const response = await fetch("https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=pk_c843c1e6284e4538a0c9791fb8a38906");
                                const check = await response.json();
                                console.log(check);
                                const a = check.latestPrice;

                                console.log("price = " + a);

                                return (a);
                            } catch (e) { }
                        }

                        const stock_name = async function (symbol) {
                            const response = await fetch("https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=pk_c843c1e6284e4538a0c9791fb8a38906");
                            const check = await response.json();
                            console.log(check);
                            const a = check.companyName;

                            console.log("name = " + a);

                            return (a);
                        }

                        const final = async function () {
                            //var p = [];
                            //var n = [];

                            for (var i = 0; i < result.length; i++) {
                                result[i].price = await stock_price(result[i].symbol);

                                result[i].name = await stock_name(result[i].symbol);
                            }
                            console.log("Record Retrieved Successfully");

                            console.log(result[0].name);
                            console.log(result[0].price);

                            var sql = "SELECT cash from users where username = '" + sess.username + "'";

                            con.query(sql, function (err, cash) {
                                console.log(sql);
                                if (err) throw err;

                                cash = JSON.parse(JSON.stringify(cash));

                                console.log(cash);
                                console.log(cash[0]);
                                console.log(cash[0].cash);

                                var total = 0;

                                for (var i = 0; i < result.length; i++) {
                                    total = total + (result[i].price * result[i].shares);
                                }

                                total = total + cash[0].cash;


                                res.render("home", { message: result, message2: sess.username, cash: cash[0].cash, total: total });
                            });
                        }

                        final();

                    }

                    else {

                        var sql = "SELECT cash from users where username = '" + sess.username + "'";

                        con.query(sql, function (err, cash) {
                            console.log(sql);
                            if (err) throw err;

                            cash = JSON.parse(JSON.stringify(cash));

                            console.log(cash);
                            console.log(cash[0]);
                            console.log(cash[0].cash);

                            var total = 0;

                            for (var i = 0; i < result.length; i++) {
                                total = total + (result[i].price * result[i].shares);
                            }

                            total = total + cash[0].cash;

                            console.log("pehle if me hai")

                            res.render("home", { message: result, message2: sess.username, cash: cash[0].cash, total: total });
                        });
                    }
                });
            }
        });
    }
    else {
        res.render("index");
    }
});

app.get("/sell", (req, res) => {
    sess = req.session;
    if (sess.username) {
        var mysql = require('mysql');
        var con = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "",
            database: "stock"
        });

        con.connect(function (err) {
            if (err) throw err;
            else {
                console.log("Connected to database for sell");
                var sql = "SELECT symbol, sum(shares) from stocks where username = '" + sess.username + "' GROUP BY symbol HAVING (SUM(shares)) > 0";

                con.query(sql, function (err, result, fields) {
                    console.log(sql);
                    if (err) throw err;

                    temp = JSON.parse(JSON.stringify(result));
                    var check = temp[0];



                    if (check) {
                        result = JSON.parse(JSON.stringify(result));
                        console.log(result);
                        console.log(result[0].symbol);
                        console.log("Record Retrieved Successfully");

                        res.render("sell", { message: result, message2: sess.username });

                        
                    }

                    else {
                        console.log("sell karne kuch nai hai")
                        res.render("sell", { message2: sess.username, error: "You don't own any stocks!" });
                    }

                });
            }
        });
    }
    else {
        res.render("index");
    }

});

app.get("/quote", (req, res) => {
    sess = req.session;
    if (sess.username) {
        res.render("quote", { message2: sess.username });
    }
    else {
        res.render("index");
    }
});

app.get("/logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return console.log(err);
        }
        res.redirect('/');
    });
});

//Gets over


//POSTS


//POST INDEX
app.post("/index", urlencodedParser, (req, res) => {

    console.log("Got body:", req.body);

    var username = req.body.username ? req.body.username : "",
        password = req.body.password ? req.body.password : "";

    var mysql = require('mysql');
    var con = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "",
        database: "stock"
    });

    con.connect(function (err) {
        if (err) throw err;
        console.log("Connected to database for checking");
        var sql = "Select * from users where username = '" + username + "' and password = '" + password + "' ";
        console.log(sql);
        con.query(sql, function (err, result) {
            //console.log(a);   
            if (err) throw err;
            else {
                console.log(result);
                console.log(result[0]);
                result = JSON.parse(JSON.stringify(result));
                var check = result[0];
                if (!check) {
                    res.render("index", { message: "Invalid Username/Password" });
                }

                else {
                    console.log("Record Retrieved Successfully");
                    sess = req.session;
                    sess.username = req.body.username;

                    console.log("ghar pe");

                    var mysql = require('mysql');
                    var con = mysql.createConnection({
                        host: "localhost",
                        user: "root",
                        password: "",
                        database: "stock"
                    });

                    con.connect(function (err) {
                        if (err) throw err;
                        else {
                            console.log("Connected to database for home");
                            var sql = "SELECT *, sum(shares) as shares FROM stocks where username = '" + sess.username + "' GROUP BY symbol HAVING (SUM(shares)) > 0";
                            con.query(sql, function (err, result) {
                                if (err) throw err;

                                console.log(result);
                                console.log(result[0]);

                                temp = JSON.parse(JSON.stringify(result));
                                var check = temp[0];

                                console.log(check);
                                console.log(temp);

                                if (check) {

                                    const stock_price = async function (symbol) {

                                        try {
                                            const response = await fetch("https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=pk_c843c1e6284e4538a0c9791fb8a38906");
                                            const check = await response.json();
                                            console.log(check);
                                            const a = check.latestPrice;

                                            console.log("price = " + a);

                                            return (a);
                                        } catch (e) { }
                                    }

                                    const stock_name = async function (symbol) {
                                        const response = await fetch("https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=pk_c843c1e6284e4538a0c9791fb8a38906");
                                        const check = await response.json();
                                        console.log(check);
                                        const a = check.companyName;

                                        console.log("name = " + a);

                                        return (a);
                                    }

                                    const final = async function () {
                                        //var p = [];
                                        //var n = [];

                                        for (var i = 0; i < result.length; i++) {
                                            result[i].price = await stock_price(result[i].symbol);

                                            result[i].name = await stock_name(result[i].symbol);
                                        }
                                        console.log("Record Retrieved Successfully");

                                        console.log(result[0].name);
                                        console.log(result[0].price);

                                        var sql = "SELECT cash from users where username = '" + sess.username + "'";

                                        con.query(sql, function (err, cash) {
                                            console.log(sql);
                                            if (err) throw err;

                                            cash = JSON.parse(JSON.stringify(cash));

                                            console.log(cash);
                                            console.log(cash[0]);
                                            console.log(cash[0].cash);

                                            var total = 0;

                                            for (var i = 0; i < result.length; i++) {
                                                total = total + (result[i].price * result[i].shares);
                                            }

                                            total = total + cash[0].cash;


                                            res.render("home", { message: result, message2: sess.username, cash: cash[0].cash, total: total });
                                        });
                                    }

                                    final();

                                }

                                else {

                                    var sql = "SELECT cash from users where username = '" + sess.username + "'";

                                    con.query(sql, function (err, cash) {
                                        console.log(sql);
                                        if (err) throw err;

                                        cash = JSON.parse(JSON.stringify(cash));

                                        console.log(cash);
                                        console.log(cash[0]);
                                        console.log(cash[0].cash);

                                        var total = 0;

                                        for (var i = 0; i < result.length; i++) {
                                            total = total + (result[i].price * result[i].shares);
                                        }

                                        total = total + cash[0].cash;

                                        console.log("pehle if me hai")

                                        res.render("home", { message: result, message2: sess.username, cash: cash[0].cash, total: total });
                                    });
                                }
                            });
                        }
                    });
                    //res.render("home", { message2: sess.username });
                }
            }
        });
    });
});

//POST REGISTER
app.post("/register", urlencodedParser, (req, res) => {

    console.log("Got body:", req.body);

    var username = req.body.username ? req.body.username : "",
        password = req.body.password ? req.body.password : "",
        password1 = req.body.password1 ? req.body.password1 : "";

    console.log(password);
    console.log(password1);

    var cash = 10000.00;

    if (password != password1) {
        res.render("register", { message3: "Password and Confirm Password do not match!" });
    }

    else {

        console.log(password);
        console.log(password1);


        var mysql = require('mysql');
        var con = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "",
            database: "stock"
        });

        con.connect(function (err) {
            if (err) throw err;

            console.log("Connected to database for inserting");

            var sql = "SELECT * from users where username = '" + username + "'";
            console.log(sql);

            con.query(sql, function (err, result) {
                console.log("select query ke andar");
                if (err) throw err;
                else {
                    result = JSON.parse(JSON.stringify(result));
                    console.log(result.length);

                    if (result.length > 0) {
                        console.log("entered");
                        res.render("register", { message3: "Username already exists!" });
                        console.log("entered");
                    }

                    else {

                        var sql = "INSERT INTO users VALUES ('" + username + "', '" + password + "', '" + cash + "')";
                        con.query(sql, function (err, result) {
                            if (err) throw err;
                            console.log("Record Inserted Successfully");
                            res.render("index");
                        });
                    }

                    console.log("entered ke bahar");
                }
                console.log("1");

            });
            console.log("2");
        });
        console.log("4");
    }
});

//POST QUOTE
app.post("/quote", urlencodedParser, (req, res) => {
    console.log("Got body:", req.body);

    var symbol = req.body.symbol ? req.body.symbol : "";

    const start = async function (symbol) {
        const response = await fetch("https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=pk_c843c1e6284e4538a0c9791fb8a38906");

        try {
            const check = await response.json();
            console.log(check);
            var a = check.symbol;
            var b = check.companyName;
            var c = check.latestPrice;
            var d = check.change;
            var e = check.changePercent;
            var f = check.companyName;
            var g = check.avgTotalVolume;
            var h = check.previousClose;

            var final = [a, b, c, d, e, f, g, h];

            console.log("u = " + sess.username);

            res.render("quote", { message: final, message2: sess.username });
        }
        catch (e) {
            console.log(e);
            res.render("quote", { message4: "Stock does not exist!", message2: sess.username });
        }
    }
    // Call start
    final = start(symbol);

    console.log("final =" + final);

});

//POST BUY
app.post("/buy", urlencodedParser, (req, res) => {
    console.log("Got body:", req.body);

    var symbol = req.body.symbol ? req.body.symbol : ""
    var shares = req.body.shares ? req.body.shares : "";

    const start = async function (symbol, shares) {
        const response = await fetch("https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=pk_c843c1e6284e4538a0c9791fb8a38906");

        try {
            const check = await response.json();
            console.log(check);
            a = check.latestPrice;

            var total = a * shares;

            var mysql = require('mysql');
            var con = mysql.createConnection({
                host: "localhost",
                user: "root",
                password: "",
                database: "stock"
            });

            con.connect(function (err) {
                if (err) throw err;
                console.log("Connected to database for buy");
                var sql = "Select cash from users where username = '" + sess.username + "' ";
                console.log(sql);
                con.query(sql, function (err, result) {
                    result = JSON.parse(JSON.stringify(result))
                    var check = result[0].cash;
                    if (check >= total) {

                        var sql = "INSERT INTO stocks (username, symbol, shares, price, operation) VALUES ('" +
                            sess.username + "', '" + symbol + "', '" + shares + "', '" + a + "', 'buy')";
                        console.log(sql);
                        con.query(sql, function (err, result) { });

                        var sql = "UPDATE users SET cash = cash - '" + total + "' WHERE username = '" + sess.username + "' ";
                        console.log(sql);
                        con.query(sql, function (err, result) { });

                        res.render("buy", { message: "Stock was bought successfully!", message2: sess.username });
                    }

                    else {
                        console.log("itna paisa nai hai");
                        res.render("buy", { message3: "Your account does not have enough balance!", message2: sess.username });
                    }
                });
            });

        }

        catch (e) {
            console.log(e);
            res.render("buy", { message3: "Stock does not exist", message2: sess.username });
        }

    }
    // Call start
    start(symbol, shares);
});

//POST SELL
app.post("/sell", urlencodedParser, (req, res) => {
    console.log("Got body:", req.body);

    var symbol = req.body.symbol ? req.body.symbol : ""
    var shares = req.body.shares ? req.body.shares : "";

    const start = async function (symbol, shares) {
        const response = await fetch("https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=pk_c843c1e6284e4538a0c9791fb8a38906");
        const check = await response.json();
        console.log(check);
        a = check.latestPrice;

        total = a * shares;

        var mysql = require('mysql');
        var con = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "",
            database: "stock"
        });

        con.connect(function (err) {
            if (err) throw err;
            console.log("Connected to database for sell");
            var sql = "Select sum(shares) from stocks where username = '" + sess.username + "' and symbol = '" + symbol + "'";
            ;
            console.log(sql);
            con.query(sql, function (err, result) {
                result = JSON.parse(JSON.stringify(result));
                var check = result[0]['sum(shares)'];
                console.log(check + " " + shares);

                if (check == 0) {
                    res.render("sell", { message3: "Your account does not have enough shares!", message2: sess.username });
                }

                else if (check >= shares) {

                    var sql = "INSERT INTO stocks (username, symbol, shares, price, operation) VALUES ('" +
                        sess.username + "', '" + symbol + "', '-" + shares + "', '" + a + "', 'sell')";
                    console.log(sql);
                    con.query(sql, function (err, result) { });

                    var sql = "UPDATE users SET cash = cash + '" + total + "' WHERE username = '" + sess.username + "' ";
                    console.log(sql);
                    con.query(sql, function (err, result) { });

                    res.render("sell", { message4: "Shares were sold successfully!", message2: sess.username });
                }


                else {
                    console.log("itna paisa nai hai");
                    res.render("sell", { message3: "Your account does not have enough shares!", message2: sess.username });
                }
            });
        });
    }
    // Call start
    start(symbol, shares);
});

app.listen(3000);